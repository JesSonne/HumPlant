#' Cajanuma
#'
#' A list containing the data form a hummingbird-plant community in Southern Ecuador.
#' The Datq consist of an interaction network along with infromation on the species' morphologies, abundances, and phenologies.
#'
#' @format A List of length 6 .
"Cajanuma"
